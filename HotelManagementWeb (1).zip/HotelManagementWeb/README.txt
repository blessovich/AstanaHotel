HOTEL MANAGEMENT WEB - JAVA + SPRING BOOT + H2 DATABASE

Запуск в Visual Studio Code на Windows БЕЗ предварительной установки Maven или Gradle:

1. Установите JDK 17 или новее.
2. Откройте в VS Code папку HotelManagementWeb.
3. Откройте Terminal -> New Terminal.
4. Выполните команду:

   .\gradlew.bat bootRun

При первом запуске скрипт автоматически скачает Gradle 8.10.2 в папку .gradle-dist.
Поэтому для первого запуска нужен интернет. Maven устанавливать не нужно.
После загрузки Gradle приложение запустится на http://localhost:8080

Остановка: Ctrl+C в терминале.

База данных H2 хранится в папке data рядом с проектом. Данные сохраняются между запусками.
Консоль базы данных: http://localhost:8080/db-console
JDBC URL: jdbc:h2:file:./data/hotel_db
User: sa
Password: (пусто)

Важно: нужен установленный JDK. Проверить можно командой:
   java -version

Если PowerShell блокирует запуск скрипта, выполните:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
а затем повторите .\gradlew.bat bootRun.
