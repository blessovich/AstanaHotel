@echo off
setlocal EnableExtensions
set "GRADLE_VERSION=8.10.2"
set "BASE_DIR=%~dp0"
set "GRADLE_HOME_LOCAL=%BASE_DIR%.gradle-dist\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME_LOCAL%\bin\gradle.bat"

if exist "%GRADLE_EXE%" goto run_gradle

where gradle >nul 2>nul
if not errorlevel 1 (
  gradle %*
  exit /b %errorlevel%
)

echo Gradle %GRADLE_VERSION% is not installed. Downloading it automatically...
if not exist "%BASE_DIR%.gradle-dist" mkdir "%BASE_DIR%.gradle-dist"
set "ZIP_FILE=%BASE_DIR%.gradle-dist\gradle-%GRADLE_VERSION%-bin.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'"
if errorlevel 1 (
  echo Download failed. Check your internet connection and try again.
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP_FILE%' -DestinationPath '%BASE_DIR%.gradle-dist' -Force"
if errorlevel 1 (
  echo Could not unpack Gradle.
  exit /b 1
)

:run_gradle
call "%GRADLE_EXE%" %*
exit /b %errorlevel%
