package com.hotel.controller;

import com.hotel.model.*;
import com.hotel.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class HotelController {
    private final ClientRepository clients;
    private final RoomRepository rooms;
    private final BookingRepository bookings;
    private final HotelInfoRepository hotels;

    public HotelController(ClientRepository c, RoomRepository r, BookingRepository b, HotelInfoRepository h) {
        clients=c; rooms=r; bookings=b; hotels=h;
    }
    private HotelInfo hotel() {
        return hotels.findById(1L).orElseGet(() -> hotels.save(new HotelInfo()));
    }
    @GetMapping("/") public String index(Model model) {
        model.addAttribute("hotel",hotel());
        model.addAttribute("clients",clients.findAll());
        model.addAttribute("rooms",rooms.findAll());
        model.addAttribute("bookings",bookings.findAll());
        model.addAttribute("freeRooms",rooms.findAll().stream().filter(r->r.getRoomStatus()=='F').count());
        return "index";
    }
    @PostMapping("/hotel") public String saveHotel(@ModelAttribute HotelInfo form) {
        HotelInfo h=hotel(); h.setHotelName(form.getHotelName()); h.setHotelAddress(form.getHotelAddress());
        h.setHotelPhone(form.getHotelPhone()); h.setTotalRooms(form.getTotalRooms());
        h.setHotelRating(form.getHotelRating()); h.setHotelCategory(form.getHotelCategory()); h.setOpen(form.isOpen());
        hotels.save(h); return "redirect:/";
    }
    @PostMapping("/clients") public String addClient(@RequestParam String name,@RequestParam int age,
            @RequestParam(defaultValue="") String passport,@RequestParam(defaultValue="") String phone,
            @RequestParam(defaultValue="0") double balance) {
        Client c=new Client(); c.setName(name); c.setAge(age); c.setPassport(passport); c.setPhone(phone); c.setBalance(balance);
        clients.save(c); return "redirect:/#clients";
    }
    @PostMapping("/rooms") public String addRoom(@RequestParam Integer roomNumber,@RequestParam String roomType,
            @RequestParam double roomPrice,@RequestParam int roomFloor,@RequestParam(defaultValue="false") boolean hasWiFi,
            @RequestParam int bedCount,@RequestParam char roomStatus) {
        Room r=new Room(); r.setRoomNumber(roomNumber); r.setRoomType(roomType); r.setRoomPrice(roomPrice);
        r.setRoomFloor(roomFloor); r.setHasWiFi(hasWiFi); r.setBedCount(bedCount); r.setRoomStatus(roomStatus);
        rooms.save(r); return "redirect:/#rooms";
    }
    @PostMapping("/rooms/{id}/toggle") public String toggleRoom(@PathVariable Integer id) {
        rooms.findById(id).ifPresent(r->{r.setRoomStatus(r.getRoomStatus()=='F'?'B':'F');rooms.save(r);});
        return "redirect:/#rooms";
    }
    @PostMapping("/bookings") public String addBooking(@RequestParam Long clientId,@RequestParam Integer roomNumber,
            @RequestParam int daysOfStay,@RequestParam double discount,@RequestParam double paymentAmount,
            RedirectAttributes redirect) {
        Client c=clients.findById(clientId).orElse(null); Room r=rooms.findById(roomNumber).orElse(null);
        if(c==null || r==null || r.getRoomStatus()!='F' || daysOfStay<1 || discount<0 || discount>100 || paymentAmount<0) {
            redirect.addFlashAttribute("error","Проверьте данные: клиент и свободный номер должны существовать.");
            return "redirect:/#booking";
        }
        double base=r.getRoomPrice()*daysOfStay, total=base*(1-discount/100.0), debt=Math.max(0,total-paymentAmount);
        Booking b=new Booking(); b.setClient(c); b.setRoom(r); b.setDaysOfStay(daysOfStay); b.setDiscount(discount);
        b.setBasePrice(base); b.setTotalPrice(total); b.setPaymentAmount(paymentAmount); b.setDebt(debt);
        b.setStatus(debt<=0?"Оплачено":"Ожидает доплаты"); bookings.save(b);
        r.setRoomStatus('B'); rooms.save(r);
        return "redirect:/#reports";
    }
    @PostMapping("/bookings/{id}/checkout") public String checkout(@PathVariable Long id) {
        bookings.findById(id).ifPresent(b->{b.getRoom().setRoomStatus('F');rooms.save(b.getRoom());});
        return "redirect:/#reports";
    }
}
