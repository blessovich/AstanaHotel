package com.hotel.model;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Booking {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false) private Client client;
    @ManyToOne(optional=false) private Room room;
    private int daysOfStay;
    private double discount;
    private double basePrice;
    private double totalPrice;
    private double paymentAmount;
    private double debt;
    private String status;
    private LocalDate createdAt=LocalDate.now();
    public Booking() {}
    public Long getId(){return id;} public Client getClient(){return client;} public void setClient(Client v){client=v;}
    public Room getRoom(){return room;} public void setRoom(Room v){room=v;}
    public int getDaysOfStay(){return daysOfStay;} public void setDaysOfStay(int v){daysOfStay=v;}
    public double getDiscount(){return discount;} public void setDiscount(double v){discount=v;}
    public double getBasePrice(){return basePrice;} public void setBasePrice(double v){basePrice=v;}
    public double getTotalPrice(){return totalPrice;} public void setTotalPrice(double v){totalPrice=v;}
    public double getPaymentAmount(){return paymentAmount;} public void setPaymentAmount(double v){paymentAmount=v;}
    public double getDebt(){return debt;} public void setDebt(double v){debt=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public LocalDate getCreatedAt(){return createdAt;}
}
