package com.hotel.model;
import jakarta.persistence.*;

@Entity
public class Client {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String name;
    private int age;
    private String passport;
    private String phone;
    private double balance;
    private boolean registered=true;
    public Client() {}
    public Long getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;}
    public int getAge(){return age;} public void setAge(int v){age=v;}
    public String getPassport(){return passport;} public void setPassport(String v){passport=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public double getBalance(){return balance;} public void setBalance(double v){balance=v;}
    public boolean isRegistered(){return registered;} public void setRegistered(boolean v){registered=v;}
}
