package com.hotel.model;
import jakarta.persistence.*;

@Entity
public class HotelInfo {
    @Id private Long id=1L;
    private String hotelName="Grand Astana Hotel";
    private String hotelAddress="Астана, Казахстан";
    private String hotelPhone="+7 (7172) 000-000";
    private int totalRooms=24;
    private float hotelRating=4.8f;
    private char hotelCategory='B';
    private boolean isOpen=true;
    public HotelInfo() {}
    public Long getId(){return id;} public String getHotelName(){return hotelName;} public void setHotelName(String v){hotelName=v;}
    public String getHotelAddress(){return hotelAddress;} public void setHotelAddress(String v){hotelAddress=v;}
    public String getHotelPhone(){return hotelPhone;} public void setHotelPhone(String v){hotelPhone=v;}
    public int getTotalRooms(){return totalRooms;} public void setTotalRooms(int v){totalRooms=v;}
    public float getHotelRating(){return hotelRating;} public void setHotelRating(float v){hotelRating=v;}
    public char getHotelCategory(){return hotelCategory;} public void setHotelCategory(char v){hotelCategory=v;}
    public boolean isOpen(){return isOpen;} public void setOpen(boolean v){isOpen=v;}
}
