package com.hotel.model;
import jakarta.persistence.*;

@Entity
@Table(name="hotel_rooms")
public class Room {
    @Id private Integer roomNumber;
    private String roomType;
    private double roomPrice;
    private int roomFloor;
    private boolean hasWiFi;
    private int bedCount;
    private char roomStatus='F';
    public Room() {}
    public Integer getRoomNumber(){return roomNumber;} public void setRoomNumber(Integer v){roomNumber=v;}
    public String getRoomType(){return roomType;} public void setRoomType(String v){roomType=v;}
    public double getRoomPrice(){return roomPrice;} public void setRoomPrice(double v){roomPrice=v;}
    public int getRoomFloor(){return roomFloor;} public void setRoomFloor(int v){roomFloor=v;}
    public boolean isHasWiFi(){return hasWiFi;} public void setHasWiFi(boolean v){hasWiFi=v;}
    public int getBedCount(){return bedCount;} public void setBedCount(int v){bedCount=v;}
    public char getRoomStatus(){return roomStatus;} public void setRoomStatus(char v){roomStatus=v;}
}
