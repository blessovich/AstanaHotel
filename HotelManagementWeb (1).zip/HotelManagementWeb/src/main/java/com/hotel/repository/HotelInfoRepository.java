package com.hotel.repository;
import com.hotel.model.HotelInfo;
import org.springframework.data.jpa.repository.JpaRepository;
public interface HotelInfoRepository extends JpaRepository<HotelInfo, Long> {
}
